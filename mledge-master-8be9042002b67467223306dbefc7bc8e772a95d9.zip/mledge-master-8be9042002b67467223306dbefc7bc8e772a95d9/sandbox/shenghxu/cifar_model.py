import tensorflow as tf
import tensorflow.contrib.slim as slim
import tensorflow.contrib.layers as layers
import numpy as np


def leaky_relu(x):
    return tf.where(tf.greater(x, 0), x, 0.2 * x)


def enet(args,x,keep_rate,phase,reuse=None):
    print 'encoder network, reuse',reuse
    with tf.variable_scope('enet',reuse=reuse):
        e = tf.layers.conv2d(inputs=x, filters=16, kernel_size=3, strides=2,activation=None, padding='same') ; print e
        e = leaky_relu(e)
        e = tf.nn.dropout(e,keep_rate)
        e = tf.layers.conv2d(inputs=e, filters=32, kernel_size=3, strides=1,activation=None, padding='same') ; print e
        e = tf.contrib.layers.batch_norm(e,center=True,scale=True,is_training=phase,scope='bn')
        e = leaky_relu(e)
        
        e = tf.nn.dropout(e,keep_rate)
        
        #e = tf.image.resize_bilinear(images=e,size=[16,16]) ; print e
        e = tf.layers.conv2d(inputs=e, filters=64, kernel_size=3, strides=2,activation=None, padding='same') ; print e
        e = tf.contrib.layers.batch_norm(e,center=True,scale=True,is_training=phase,scope='bn2')
        e = leaky_relu(e)
        e = tf.nn.dropout(e,keep_rate)
        
        e = tf.layers.conv2d(inputs=e, filters=128, kernel_size=3, strides=1,activation=None, padding='same') ; print e
        e = tf.contrib.layers.batch_norm(e,center=True,scale=True,is_training=phase,scope='bn3')
        e = leaky_relu(e)
        e = tf.nn.dropout(e,keep_rate)
        
        #e = tf.image.resize_bilinear(images=e,size=[8,8]) ; print e
        e = tf.layers.conv2d(inputs=e, filters=256, kernel_size=3, strides=2,activation=None, padding='same'); print e
        e = tf.contrib.layers.batch_norm(e,center=True,scale=True,is_training=phase,scope='bn4')
        e = leaky_relu(e)
        e = tf.nn.dropout(e,keep_rate)
        
        e = tf.layers.conv2d(inputs=e, filters=512, kernel_size=3, strides=1,activation=None, padding='same') ; print e
        e = tf.contrib.layers.flatten(e) ; print e
        #e = tf.layers.dense(inputs=e, units=11, activation=tf.nn.elu) ; print e
        #e = tf.layers.dense(inputs=e, units=l.shape[1], activation=tf.sigmoid) ; print e
       # e = tf.concat([e,l],axis=1) ; print e
      #  e = tf.layers.dense(inputs=e, units=100, activation=tf.nn.elu) ; print e
      #  e = tf.layers.dense(inputs=e, units=100, activation=tf.nn.elu) ; print e
      #  e = tf.layers.dense(inputs=e, units=100, activation=tf.nn.elu) ; print e
      #  e = tf.layers.dense(inputs=e, units=100, activation=tf.nn.elu) ; print e
        cat = tf.layers.dense(inputs=e,units=10, activation=tf.nn.elu); print cat
        con = tf.layers.dense(inputs=e,units=2,  activation=tf.nn.sigmoid); print con
        e = tf.layers.dense(inputs=e, units=10, activation=tf.nn.elu) ; print e
        e = tf.layers.dense(inputs=e, units=1, activation=tf.sigmoid) ; print e
        e = tf.identity(e,name='eout') ; print e
    return e, cat, con


def gnet(args,z,phase,reuse=None):
    print 'generator network, reuse', reuse
    with tf.variable_scope('gnet',reuse=reuse):
#        l = tf.layers.dense(inputs=z, units=100, activation=tf.nn.elu) ; print l
#        l = tf.layers.dense(inputs=l, units=100, activation=tf.nn.elu) ; print l
#        l = tf.layers.dense(inputs=l, units=100, activation=tf.nn.elu) ; print l
#        l = tf.layers.dense(inputs=l, units=100, activation=tf.nn.elu) ; print l
#        l = tf.layers.dense(inputs=l, units=10, activation=tf.nn.softmax) ; print l
#        l = tf.identity(l,name='lout') ; print l
#        l = tf.gather_cols(z,[0,1,2,3,4,5,6,7,8,9]) ;
        ind = tf.constant([0,1,2,3,4,5,6,7,8,9])
        #l = tf.transpose(tf.nn.embedding_lookup(tf.transpose(z),ind))
        #l = tf.transpose(tf.nn.embedding_lookup(tf.transpose(z_cat),ind))
        g = tf.layers.dense(inputs=z, units=384, activation=tf.nn.relu) ; print g
        g = tf.reshape(g,[-1,4,4,24]) ; print g
        g = tf.layers.conv2d_transpose(inputs=g, filters=192, kernel_size=5, strides=2,activation=None, padding='same') ; print g
        g = tf.contrib.layers.batch_norm(g,center=True,scale=True,is_training=phase,scope='gbn1')
        g = tf.nn.relu(g)
        g = tf.layers.conv2d_transpose(inputs=g, filters=96, kernel_size=5, strides=2,activation=None, padding='same') ; print g
        g = tf.contrib.layers.batch_norm(g,center=True,scale=True,is_training=phase,scope='gbn2')
        g = tf.nn.relu(g)
        #g = tf.image.resize_bilinear(images=g,size=[16,16]) ; print g
        g = tf.layers.conv2d_transpose(inputs=g, filters=3, kernel_size=5, strides=2,activation=tf.nn.tanh, padding='same') ; print g
        #g = tf.layers.conv2d(inputs=g, filters=args.n, kernel_size=3, strides=1,activation=tf.nn.elu, padding='same') ; print g
        #g = tf.image.resize_bilinear(images=g,size=[32,32]) ; print g
        #g = tf.layers.conv2d(inputs=g, filters=args.n, kernel_size=3, strides=1,activation=tf.nn.elu, padding='same') ; print g
        #g = tf.layers.conv2d(inputs=g, filters=args.n, kernel_size=3, strides=1,activation=tf.nn.elu, padding='same') ; print g
        #g = tf.layers.conv2d(inputs=g, filters=3, kernel_size=3, strides=1,activation=None, padding='same') ; print g
        #g = tf.identity(g,name='gout') ; print g
    return g