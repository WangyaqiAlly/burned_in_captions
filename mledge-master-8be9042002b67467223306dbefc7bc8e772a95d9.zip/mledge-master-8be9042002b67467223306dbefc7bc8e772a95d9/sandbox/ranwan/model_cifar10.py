import tensorflow as tf
import tensorflow.contrib.slim as slim
import tensorflow.contrib.layers as layers
import numpy as np

def leaky_relu(x):
    return tf.where(tf.greater(x, 0), x, 0.01 * x)

# def enet(args,tensor,reuse=None):
#     print 'encoder network, reuse',reuse
#     with tf.variable_scope('enet',reuse=reuse):
#         tensor = slim.conv2d(tensor, num_outputs = 16, kernel_size=[3,3], stride=2, activation_fn=tf.nn.elu)
#         #tensor = tf.contrib.layers.dropout(inputs = tensor, keep_prob = 0.5)
#         tensor = slim.conv2d(tensor, num_outputs=32, kernel_size=[3,3], stride=1, activation_fn=tf.nn.elu)
#         #tensor = slim.batch_norm(tensor, activation_fn = tf.nn.relu)
#         #tensor = tf.contrib.layers.dropout(inputs = tensor, keep_prob = 0.5)
#         tensor = slim.conv2d(tensor, num_outputs=64, kernel_size=[3,3], stride=2, activation_fn=tf.nn.elu)
#         #tensor = slim.batch_norm(tensor, activation_fn = tf.nn.relu)
#         #tensor = tf.contrib.layers.dropout(inputs = tensor, keep_prob = 0.5)
#         tensor = slim.conv2d(tensor, num_outputs=128, kernel_size=[3,3], stride=1, activation_fn=tf.nn.elu)
#         #tensor = slim.batch_norm(tensor, activation_fn = tf.nn.relu)
#         #tensor = tf.contrib.layers.dropout(inputs = tensor, keep_prob = 0.5)
#         tensor = slim.conv2d(tensor, num_outputs=256, kernel_size=[3,3], stride=2, activation_fn=tf.nn.elu)
#         #tensor = slim.batch_norm(tensor, activation_fn = tf.nn.relu)
#         #tensor = tf.contrib.layers.dropout(inputs = tensor, keep_prob = 0.5)
#         tensor = slim.conv2d(tensor, num_outputs=512, kernel_size=[3,3], stride=1, activation_fn=tf.nn.elu)
#         #tensor = slim.batch_norm(tensor, activation_fn = tf.nn.relu)
#         #tensor = tf.contrib.layers.dropout(inputs = tensor, keep_prob = 0.5)
#         tensor = slim.flatten(tensor)
#         # shared_tensor = slim.fully_connected(tensor, num_outputs=11, activation_fn = leaky_relu)
#         # shared_tensor = tf.contrib.layers.dropout(inputs = shared_tensor, keep_prob = 0.5)
#         # recog_shared = slim.fully_connected(shared_tensor, num_outputs=128, activation_fn = leaky_relu)
#         # recog_shared = tf.contrib.layers.dropout(inputs = recog_shared, keep_prob = 0.5)
#         # disc = slim.fully_connected(shared_tensor, num_outputs=1, activation_fn=None)
#         # disc = tf.squeeze(disc, -1)
#         # recog_cat = slim.fully_connected(recog_shared, num_outputs=args.cat_dim, activation_fn=None)
#         # recog_cont = slim.fully_connected(recog_shared, num_outputs=args.con_dim, activation_fn=tf.nn.sigmoid)
#         shared_tensor = slim.fully_connected(tensor, num_outputs=100, activation_fn = tf.nn.elu)
#         #shared_tensor = tf.contrib.layers.dropout(inputs = shared_tensor, keep_prob = 0.5)
#         disc = slim.fully_connected(shared_tensor, num_outputs=1, activation_fn=tf.nn.sigmoid)
#         #disc = tf.squeeze(disc, -1)
#         disc = tf.clip_by_value(disc,1e-7, 1.-1e-7)
#         recog_cat = slim.fully_connected(shared_tensor, num_outputs=args.cat_dim, activation_fn=None)
#         recog_cont = slim.fully_connected(shared_tensor, num_outputs=args.con_dim, activation_fn=None)
#     return disc, recog_cat, recog_cont


# def gnet(args,tensor,reuse=None):
#     print 'generator network, reuse', reuse
#     with tf.variable_scope('gnet',reuse=reuse):
#         tensor = slim.fully_connected(tensor, 4*4*128)
#         print tensor
#         tensor = tf.reshape(tensor, [-1, 4, 4, 128])
#         # print '22',tensor.get_shape()
#         tensor = slim.conv2d_transpose(tensor, 192, kernel_size=[5,5], stride=2, activation_fn = tf.nn.elu)
#         #tensor = slim.batch_norm(tensor, activation_fn = tf.nn.relu)
#         tensor = slim.conv2d_transpose(tensor, 96, kernel_size=[5,5], stride=2, activation_fn = tf.nn.elu)
#         #tensor = slim.batch_norm(tensor, activation_fn = tf.nn.relu)
#         tensor = slim.conv2d_transpose(tensor, 3, kernel_size=[5, 5], stride=2, activation_fn=tf.nn.tanh)
#     return tensor


def encoder(input_images, reuse=False):
    print 'DISCRIMINATOR' 
    with tf.variable_scope('disc_enc', reuse=reuse):
        print 'input images:',input_images
        conv1 = layers.conv2d(input_images, 64, 4, stride=2, activation_fn=None, scope='d_conv1')
        conv1 = tf.nn.elu(conv1)
        print 'conv1:',conv1

        conv2 = layers.conv2d(conv1, 128, 4, stride=2, normalizer_fn=layers.batch_norm, activation_fn=None, scope='d_conv2')
        conv2 = tf.nn.elu(conv2)
        print 'conv2:',conv2

        conv3 = layers.conv2d(conv2, 256, 4, stride=2, normalizer_fn=layers.batch_norm, activation_fn=None, scope='d_conv3')
        conv3 = tf.nn.elu(conv3)
        print 'conv3:',conv3

        conv4 = layers.conv2d(conv3, 256, 4, stride=2, normalizer_fn=layers.batch_norm, activation_fn=None, scope='d_conv4')
        conv4 = tf.nn.elu(conv4)
        print 'conv4:',conv4

        # tf.add_to_collection('vars', conv1)
        # tf.add_to_collection('vars', conv2)
        # tf.add_to_collection('vars', conv3)

        return conv4

def decoder(encoded, reuse=False):
    with tf.variable_scope('disc_dec', reuse=reuse):
      
        conv5 = layers.conv2d_transpose(encoded, 256, 4, stride=2, normalizer_fn=layers.batch_norm, activation_fn=None, scope='d_conv5')
        conv5 = tf.nn.elu(conv5)
        print 'conv5:',conv5

        conv6 = layers.conv2d_transpose(conv5, 128, 4, stride=2, normalizer_fn=layers.batch_norm, activation_fn=None, scope='d_conv6')
        conv6 = tf.nn.elu(conv6)
        print 'conv6:',conv6

        conv7 = layers.conv2d_transpose(conv6, 64, 4, stride=2, activation_fn=layers.batch_norm, scope='d_conv7')
        conv7 = tf.nn.tanh(conv7)
        print 'conv7:',conv7

        conv8 = layers.conv2d_transpose(conv7, 3, 4, stride=2, activation_fn=None, scope='d_conv8')
        conv8 = tf.nn.tanh(conv8)
        print 'conv8:',conv8

        print 'END D\n'
        # tf.add_to_collection('vars', conv4)
        # tf.add_to_collection('vars', conv5)
        # tf.add_to_collection('vars', conv6)

        return conv8

def mse(pred, real, batch_size):
    return tf.sqrt(tf.nn.l2_loss(pred-real))/batch_size

def pullaway_loss(args,embeddings):
    norm = tf.sqrt(tf.reduce_sum(tf.square(embeddings), 1, keep_dims=True))
    normalized_embeddings = embeddings / norm
    similarity = tf.matmul(normalized_embeddings, normalized_embeddings, transpose_b=True)
    pt_loss = (tf.reduce_sum(similarity) - args.batch) / (args.batch * (args.batch - 1))
    return pt_loss

def enet_energy(args, input_images, reuse=False):
    with tf.variable_scope('enet_energy',reuse=reuse):
        encoded = encoder(input_images, reuse=reuse)
        decoded = decoder(encoded, reuse=reuse)
        shared = tf.contrib.layers.flatten(encoded)
        shared = tf.layers.dense(inputs=shared,units=100, activation=tf.nn.elu)
        shared = tf.layers.dense(inputs=shared,units=100, activation=tf.nn.elu)
        cat = tf.layers.dense(inputs=shared,units=10, activation=None)
        con = tf.layers.dense(inputs=shared,units=2,  activation=None)

    return mse(decoded, input_images, args.batch), cat, con, encoded

def enet(args,x,reuse=None):
    print 'encoder network, reuse',reuse
    with tf.variable_scope('enet',reuse=reuse):
        e = tf.layers.conv2d(inputs=x, filters=args.n, kernel_size=3, strides=1,activation=tf.nn.elu, padding='same') ; print e
        e = tf.layers.conv2d(inputs=e, filters=args.n, kernel_size=3, strides=2,activation=tf.nn.elu, padding='same') ; print e
        #e = tf.image.resize_bilinear(images=e,size=[16,16]) ; print e
        e = tf.layers.conv2d(inputs=e, filters=2*args.n, kernel_size=3, strides=1,activation=tf.nn.elu, padding='same') ; print e
        e = tf.layers.conv2d(inputs=e, filters=2*args.n, kernel_size=3, strides=2,activation=tf.nn.elu, padding='same') ; print e
        #e = tf.image.resize_bilinear(images=e,size=[8,8]) ; print e
        e = tf.layers.conv2d(inputs=e, filters=4*args.n, kernel_size=3, strides=1,activation=tf.nn.elu, padding='same') ; print e
        e = tf.layers.conv2d(inputs=e, filters=4*args.n, kernel_size=3, strides=1,activation=tf.nn.elu, padding='same') ; print e
        e = tf.contrib.layers.flatten(e) ; print e
        e = tf.layers.dense(inputs=e, units=100, activation=tf.nn.elu) ; print e
        #e = tf.layers.dense(inputs=e, units=l.shape[1], activation=tf.nn.elu) ; print e
        #e = tf.concat([e,l],axis=1) ; print e
      #  e = tf.layers.dense(inputs=e, units=100, activation=tf.nn.elu) ; print e
      #  e = tf.layers.dense(inputs=e, units=100, activation=tf.nn.elu) ; print e
      #  e = tf.layers.dense(inputs=e, units=100, activation=tf.nn.elu) ; print e
        e = tf.layers.dense(inputs=e, units=100, activation=tf.nn.elu) ; print e
        cat = tf.layers.dense(inputs=e,units=10, activation=None); print cat
        con = tf.layers.dense(inputs=e,units=2,  activation=None); print con
        e = tf.layers.dense(inputs=e, units=10, activation=tf.nn.elu) ; print e
        e = tf.layers.dense(inputs=e, units=1, activation=tf.sigmoid) ; print e
        e = tf.clip_by_value(e,1e-7, 1.-1e-7) ; print e
    return e, cat, con


def gnet(args,z,reuse=None):
    print 'generator network, reuse', reuse
    with tf.variable_scope('gnet',reuse=reuse):
        g = tf.layers.dense(inputs=z, units=8*8*args.n, activation=None) ; print g
        g = tf.reshape(g,[-1,8,8,args.n]) ; print g
        g = tf.layers.conv2d(inputs=g, filters=args.n, kernel_size=3, strides=1,activation=tf.nn.elu, padding='same') ; print g
        g = tf.layers.conv2d_transpose(inputs=g, filters=args.n, kernel_size=3, strides=2,activation=tf.nn.elu, padding='same') ; print g
        #g = tf.image.resize_bilinear(images=g,size=[16,16]) ; print g
        g = tf.layers.conv2d(inputs=g, filters=args.n, kernel_size=3, strides=1,activation=tf.nn.elu, padding='same') ; print g
        g = tf.layers.conv2d_transpose(inputs=g, filters=args.n, kernel_size=3, strides=2,activation=tf.nn.elu, padding='same') ; print g
        #g = tf.image.resize_bilinear(images=g,size=[32,32]) ; print g
        g = tf.layers.conv2d(inputs=g, filters=args.n, kernel_size=3, strides=1,activation=tf.nn.elu, padding='same') ; print g
        g = tf.layers.conv2d(inputs=g, filters=args.n, kernel_size=3, strides=1,activation=tf.nn.elu, padding='same') ; print g
        g = tf.layers.conv2d(inputs=g, filters=3, kernel_size=3, strides=1,activation=None, padding='same') ; print g
        g = tf.identity(g,name='gout') ; print g
    return g


# def gnet(args,z,reuse=None):
#     print 'generator network, reuse', reuse
#     with tf.variable_scope('gnet',reuse=reuse):
#         g = tf.layers.dense(inputs=z, units=8*8*args.n, activation=None) ; print g
#         g = tf.reshape(g,[-1,8,8,args.n]) ; print g
#         g = layers.conv2d_transpose(inputs=g, num_outputs=args.n, kernel_size=4, stride=1,normalizer_fn=layers.batch_norm,activation_fn=None) ; print g
#         g = tf.nn.elu(g)
#         g = layers.conv2d_transpose(inputs=g, num_outputs=args.n, kernel_size=4, stride=2,normalizer_fn=layers.batch_norm,activation_fn=None) ; print g
#         #g = tf.image.resize_bilinear(images=g,size=[16,16]) ; print g
#         g = tf.nn.elu(g)
#         g = layers.conv2d_transpose(inputs=g, num_outputs=args.n, kernel_size=4, stride=1,normalizer_fn=layers.batch_norm,activation_fn=None) ; print g
#         g = tf.nn.elu(g)
#         g = layers.conv2d_transpose(inputs=g, num_outputs=args.n, kernel_size=4, stride=2,normalizer_fn=layers.batch_norm,activation_fn=None) ; print g
#         g = tf.nn.elu(g)
#         #g = tf.image.resize_bilinear(images=g,size=[32,32]) ; print g
#         g = layers.conv2d_transpose(inputs=g, num_outputs=args.n, kernel_size=4, stride=1,normalizer_fn=layers.batch_norm,activation_fn=None) ; print g
#         g = tf.nn.elu(g)
#         g = layers.conv2d_transpose(inputs=g, num_outputs=args.n, kernel_size=4, stride=1,normalizer_fn=layers.batch_norm,activation_fn=None) ; print g
#         g = tf.nn.elu(g)
#         g = layers.conv2d_transpose(inputs=g, num_outputs=3, kernel_size=4, stride=1,activation_fn=tf.nn.tanh) ; print g
#         g = tf.identity(g,name='gout') ; print g
#     return g

# def enet(args,x,reuse=None):
#     print 'encoder network, reuse',reuse
#     with tf.variable_scope('enet',reuse=reuse):
#         e = tf.layers.conv2d(inputs=x, filters=args.n, kernel_size=3, strides=1,activation=tf.nn.elu, padding='same') ; print e
#         e = tf.layers.conv2d(inputs=e, filters=args.n, kernel_size=3, strides=2,activation=None, padding='same') ; print e
#         e = slim.batch_norm(e,activation_fn=tf.nn.elu)
#         e = tf.layers.conv2d(inputs=e, filters=2*args.n, kernel_size=3, strides=1,activation=None, padding='same') ; print e
#         e = slim.batch_norm(e,activation_fn=tf.nn.elu)
#         e = tf.layers.conv2d(inputs=e, filters=2*args.n, kernel_size=3, strides=2,activation=None, padding='same') ; print e
#         e = slim.batch_norm(e,activation_fn=tf.nn.elu)
#         e = tf.layers.conv2d(inputs=e, filters=4*args.n, kernel_size=3, strides=1,activation=None, padding='same') ; print e
#         e = slim.batch_norm(e,activation_fn=tf.nn.elu)
#         e = tf.layers.conv2d(inputs=e, filters=4*args.n, kernel_size=3, strides=1,activation=None, padding='same') ; print e
#         e = slim.batch_norm(e,activation_fn=tf.nn.elu)
#         e = tf.contrib.layers.flatten(e) ; print e
#         e = tf.layers.dense(inputs=e, units=100, activation=None) ; print e
#         e = slim.batch_norm(e,activation_fn=tf.nn.elu)
#         #e = tf.layers.dense(inputs=e, units=l.shape[1], activation=tf.nn.elu) ; print e
#         #e = tf.concat([e,l],axis=1) ; print e
#       #  e = tf.layers.dense(inputs=e, units=100, activation=tf.nn.elu) ; print e
#       #  e = tf.layers.dense(inputs=e, units=100, activation=tf.nn.elu) ; print e
#       #  e = tf.layers.dense(inputs=e, units=100, activation=tf.nn.elu) ; print e
#         e = tf.layers.dense(inputs=e, units=100, activation=None) ; print e
#         e = slim.batch_norm(e,activation_fn=tf.nn.elu)
#         cat = tf.layers.dense(inputs=e,units=10, activation=None); print cat
#         con = tf.layers.dense(inputs=e,units=2,  activation=None); print con
#         e = tf.layers.dense(inputs=e, units=10, activation=tf.nn.elu) ; print e
#         e = tf.layers.dense(inputs=e, units=1, activation=tf.sigmoid) ; print e
#         e = tf.clip_by_value(e,1e-7, 1.-1e-7) ; print e
#     return e, cat, con

# def gnet(args,z,reuse=None):
#     print 'generator network, reuse', reuse
#     with tf.variable_scope('gnet',reuse=reuse):
#         g = tf.layers.dense(inputs=z, units=8*8*args.n, activation=None) ; print g
#         g = tf.reshape(g,[-1,8,8,args.n]) ; print g
#         g = tf.layers.conv2d_transpose(inputs=g, filters=args.n, kernel_size=3, strides=1,activation=None, padding='same') ; print g
#         g = slim.batch_norm(g,activation_fn=tf.nn.elu)
#         g = tf.layers.conv2d_transpose(inputs=g, filters=args.n, kernel_size=3, strides=2,activation=None, padding='same') ; print g
#         g = slim.batch_norm(g,activation_fn=tf.nn.elu)
#         g = tf.layers.conv2d_transpose(inputs=g, filters=args.n, kernel_size=3, strides=1,activation=None, padding='same') ; print g
#         g = slim.batch_norm(g,activation_fn=tf.nn.elu)
#         g = tf.layers.conv2d_transpose(inputs=g, filters=args.n, kernel_size=3, strides=2,activation=None, padding='same') ; print g
#         g = slim.batch_norm(g,activation_fn=tf.nn.elu)
#         g = tf.layers.conv2d_transpose(inputs=g, filters=args.n, kernel_size=3, strides=1,activation=None, padding='same') ; print g
#         g = slim.batch_norm(g,activation_fn=tf.nn.elu)
#         g = tf.layers.conv2d_transpose(inputs=g, filters=args.n, kernel_size=3, strides=1,activation=None, padding='same') ; print g
#         g = slim.batch_norm(g,activation_fn=tf.nn.elu)
#         g = tf.layers.conv2d_transpose(inputs=g, filters=3, kernel_size=3, strides=1,activation=tf.nn.tanh, padding='same') ; print g
#         g = tf.identity(g,name='gout') ; print g
#     return g