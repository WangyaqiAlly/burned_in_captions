# W-AC-gan
## Data
Data can be downloaded from http://hydra-02.cisco.com/Data/cifar-10-division.tar

## Example of running the code
python wacgan_multiedge.py -t 1 -eid '1' -max_e 10000 -dir 'Directory_to_the_cifar_dataset' -rp 'Directory_of_recorded_infomation'