#### data_filtering

Main file: cifar10_wacage_filter
Lib files: cifar10_input.py, hyper_parameters.py, resnet.py

*Requirement* tflib folder, generated images & label, and trained classifier model.
Path of the data/saving and models are set inside the code. Change if needed.

#### wacage_label_by_golden.py
Re-generate label for generated images using golden classifier

*Requirement* tflib folder, generated images, and trained golden classifier.
